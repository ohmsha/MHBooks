import tensorflow as tf
from tensorflow import keras
import numpy as np
import os

import cv2

model = keras.models.load_model(os.path.join('result', 'outmodel'))

#画像の取得と評価
cap = cv2.VideoCapture(0)
while True:
	ret, frame = cap.read()
	gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
	xp = int(frame.shape[1]/2)
	yp = int(frame.shape[0]/2)
	d = 40
	cv2.rectangle(gray, (xp-d, yp-d), (xp+d, yp+d), color=0, thickness=2)
	cv2.imshow('gray', gray)
	if cv2.waitKey(100) == ord('q'):
		break
	gray = cv2.resize(gray[yp-d:yp + d, xp-d:xp + d],(8, 8))
	img = 16.0 - np.asarray(gray, dtype=np.float32) / 16.0 # 白黒反転，0-16に正規化，array化
	test_data = img.reshape(1, 8, 8, 1) # 4次元行列に変換（1×1×8×8，バッチ数×チャンネル数×縦×横）
	prediction = model.predict(test_data)
	result = np.argmax(prediction)
	print(f'result: {result}')
cap.release()
