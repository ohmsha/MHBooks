# -*- coding: utf-8 -*-
import serial

ser = serial.Serial('COM3', 9600,timeout=0.5)
td = [0x7E, 0x00, 0x15, 0x11, 0x00, 0x00, 0x13, 0xA2, 0x00, 0x41, 0x8C, 0xD9, 0x80, 0xFF, 0xFE, 0xE8, 0xE8, 0x00, 0x11, 0xC1, 0x05, 0x00, 0x00]

td.append(ord('a'))
td.append(ord('b'))
td.append(ord('c'))
m = 0
for i in range(3,len(td)):
    m = m + td[i]
m = 255 - m %256;
td.append(m)

td[1] = int((len(td)-4)/256)
td[2] = (len(td)-4)%256

for i in range(0,len(td)):
    print(hex(td[i]))
    c = bytes.fromhex(format(td[i], '02x'))
    ser.write(c)
    
print('Recieve Data')
n = 0
m = 0
while True:
    c=ser.read()
    if n==0:
        if c == b'\x7e':
            n = 1
    elif n==1:
        m = ord(c)*256
        n = n+1
    elif n == 2:
        m = m + ord(c)
        n = n+1
    elif n>=21 and n<=m+2:
        print(c)
        n = n+1
    elif n==m+3:
        break
    else:
        n = n+1

ser.close()
