# -*- coding: utf-8 -*-
import serial

ser = serial.Serial('COM11', 9600,timeout=0.5)
td = [0x7E, 0x00, 0x15, 0x11, 0x00, 0x00, 0x13, 0xA2, 0x00, 0x41, 0x99, 0x28, 0x7A, 0xFF, 0xFE, 0xE8, 0xE8, 0x00, 0x11, 0xC1, 0x05, 0x00, 0x00]

td.append(ord('a'))
td.append(ord('b'))
td.append(ord('c'))
m = 0
for i in range(3,len(td)):
    m = m + td[i]
m = 255 - m %256;
td.append(m)

td[1] = int((len(td)-4)/256)
td[2] = (len(td)-4)%256

for i in range(0,len(td)):
    print(hex(td[i]))
    c = bytes.fromhex(format(td[i], '02x'))
    ser.write(c)
ser.close()
