# -*- coding: utf-8 -*-
import serial
import time

ser = serial.Serial('COM9', 9600)
time.sleep(2)
for _ in range(20):
    ser.write(b"a")
    time.sleep(0.5)
ser.close()
