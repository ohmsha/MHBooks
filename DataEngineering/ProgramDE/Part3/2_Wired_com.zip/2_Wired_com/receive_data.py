# -*- coding: utf-8 -*-
import serial
import time

ser = serial.Serial('COM9', 9600,timeout=0.5)
time.sleep(2)

while True:
    c = ser.read()
    print(c)
    if c == b'\n':
        break
ser.close()
