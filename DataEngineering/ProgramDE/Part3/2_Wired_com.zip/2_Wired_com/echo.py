# -*- coding: utf-8 -*-
import serial
import time

ser = serial.Serial('COM11', 9600,timeout=0.5)
time.sleep(2)
ser.write(b"abc\n")

while True:
    c = ser.read()
    print(c)
    if c == b'\n':
        break
ser.close()
