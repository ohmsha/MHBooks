# -*- coding: utf-8 -*-
import serial
import time

ser = serial.Serial('COM3', 9600,timeout=0.5)
time.sleep(2)

a = 0
t = 0
with open('data.txt', 'w') as f:
    while True:
        n = 0
        a = ''
        while True:
            c=ser.read()
            if n==0:
                if c == b'\x7e':
                    n = 1
            elif n==11 or n==12:
                n = n+1
                a = a + c.hex()
            elif n==13:
                n = 0
                break
            else:
                n = n+1
        text = '{0}\t{1}\n'.format(t, int(a,16))
        print(text)
        f.write(text)
        t = t+1
ser.close()
