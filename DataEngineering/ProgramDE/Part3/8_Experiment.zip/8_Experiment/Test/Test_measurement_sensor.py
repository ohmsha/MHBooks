# -*- coding: utf-8 -*-
import serial
import time

ser = serial.Serial('COM3', 9600,timeout=0.5)
time.sleep(2)
ser.write(b"a ")

n = 0
while True:
    a = ''
    while True:
        c = ser.read()
        if c == b'\n':
            break
        a = a+c.decode()
    a = float(a)/1023*5/0.01
    print(n, a)
    n = n + 1
ser.close()
