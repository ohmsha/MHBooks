# -*- coding: utf-8 -*-
import numpy as np
import matplotlib.pyplot as plt

da = np.loadtxt('data.txt')

plt.plot(da[:,0],da[:,1])
plt.show()
