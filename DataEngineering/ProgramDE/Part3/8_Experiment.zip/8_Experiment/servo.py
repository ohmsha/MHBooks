# -*- coding: utf-8 -*-
import serial
import time

ser = serial.Serial('COM3', 9600,timeout=0.5)
time.sleep(2)

a = 0
while True:
    ser.write((str(a)+'\n').encode('utf-8'))
    a = a + 10
    if a == 120:
        a=0
    time.sleep(0.2)
ser.close()
