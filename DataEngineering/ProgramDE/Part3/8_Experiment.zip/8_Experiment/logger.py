# -*- coding: utf-8 -*-
import serial
import time

ser = serial.Serial('COM3', 9600,timeout=0.5)
time.sleep(2)

a = 0

while True:
    n = 0
    a = ''
    while True:
        c=ser.read()
        if n==0:
            if c == b'\x7e':
                n = 1
        elif n==11 or n==12:
            n = n+1
            a = a + c.hex()
        elif n==13:
            n = 0
            break
        else:
            n = n+1
    print(int(a,16))
ser.close()
