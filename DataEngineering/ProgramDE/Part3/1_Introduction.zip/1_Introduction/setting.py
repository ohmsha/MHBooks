# -*- coding: utf-8 -*-
import serial

ser = serial.Serial('COM12', 9600,timeout=0.5)
print(ser)
ser.close()
