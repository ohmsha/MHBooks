# -*- coding: utf-8 -*-
import socket

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
client.settimeout(1)
client.connect(("192.168.0.2", 9750))

client.send("abc".encode('utf-8')) 

response = client.recv(4096) 
print(response)
