#pragma once
double print_array(int n, double x[10]);