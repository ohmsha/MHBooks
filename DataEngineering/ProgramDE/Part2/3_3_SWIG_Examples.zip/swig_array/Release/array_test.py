import swig_array

MaxNum = 10

a = swig_array.new_doubleArray(MaxNum)             # Create an array
for i in range(0, MaxNum):
    swig_array.doubleArray_setitem(a, i, i)  # Set a value

average = swig_array.my_average(MaxNum,a)            # Pass to C
print("average=", end="") #改行しない
print(average)

swig_array.delete_doubleArray(a)               # Destroy array


#MaxNum = 10
#data = [0 for i in range(MaxNum)]
#for i in range(0, MaxNum):
#    data[i] = i
#print(data)
#_swig_array.my_average(MaxNum,data)
