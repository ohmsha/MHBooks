#include <stdio.h>

int my_add(int a, int b) {
	int ans = 0;
	ans=a+b;

	printf("%d\n", ans);

	return (ans);
}

