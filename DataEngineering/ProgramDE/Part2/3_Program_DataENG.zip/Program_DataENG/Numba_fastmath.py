# -*- coding: utf-8 -*-
# test fastmath
# https://numba.pydata.org/numba-doc/dev/user/performance-tips.html#fastmath

import numpy as np
import time
import numba

@numba.njit(fastmath=False)
def do_sum(A):
    sum = 0.
    for x in A:
        sum += np.sqrt(x)
    return sum
    
@numba.njit(fastmath=True)
def do_sum_fast(A):
    sum = 0.
    for x in A:
        sum += np.sqrt(x)
    return sum    
    

vec = np.array(range(1000))    

time1 = time.perf_counter()
print('no fastmath result =',do_sum(vec))
time2 = time.perf_counter()
print('fastmath result    =',do_sum_fast(vec))
time3 = time.perf_counter()

elapsed_time_1 = time2 - time1
elapsed_time_2 = time3 - time2

print("elapsed time")
print("no fastmath %e" % elapsed_time_1)
print("fastmat     %e" % elapsed_time_2)
