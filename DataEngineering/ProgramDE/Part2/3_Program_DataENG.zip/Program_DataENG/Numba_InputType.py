# -*- coding: utf-8 -*-
import numpy as np
import time
import numba

@numba.njit
def sum1(array, coef, num):
    sum = 0.0
    for i in range(num):
        sum += array[i]*coef
    return sum

@numba.njit('f8(f8[:], f8, i8)')
def sum1_input_type(array, coef, num):
    sum = 0.0
    for i in range(num):
        sum += array[i]*coef
    return sum

num = int(10**5)
a = np.arange(num, dtype=np.float64)
coef = 0.5

time1 = time.perf_counter()
print(sum1(a, coef, num))
time2 = time.perf_counter()
print(sum1_input_type(a, coef, num))
time3 = time.perf_counter()

elapsed_time_1 = time2 - time1
elapsed_time_2 = time3 - time2

print("(1)elapsed_time %e" % elapsed_time_1)
print("(2)elapsed_time %e" % elapsed_time_2)