# -*- coding: utf-8 -*-
# 子プロセス間でデータを送る
#
from multiprocessing import Pipe, Process
import time
import datetime
#import random
import os
 
 
def reader_proc(pipe):
    print("process id of reader_proc:", os.getpid())
    print("parent process:", os.getppid())
    msg=' ' # 初期設定，最初pollingがFalseのときのif文を成立させるため
    num = 0
    while True:
        if pipe.poll():
            msg = pipe.recv()    # Read from the pipe2
            num += 1
        if msg=='EXIT':
            print('num =', num-1) # '-1' for polling 
            break
            
def writer_proc(count, pipe):
    print("process id of writer_proc:", os.getpid())
    print("parent process:", os.getppid())
    for i in range(count):
        pipe.send(i)             # Write 'count' numbers into the pipe1
    pipe.send('EXIT')
 
if __name__ == '__main__':
 
    count = 10**5
    pipe1, pipe2 = Pipe()  # writer() writes from pipe1 to pipe2 in reader_proc
    reader_p = Process(target=reader_proc, args=(pipe2,))
    reader_p.daemon = True
    reader_p.start()     # Launch the reader_proc()

    writer_p = Process(target=writer_proc, args=(count, pipe1,))
    writer_p.daemon = True
    writer_p.start()     # Launch the writer_proc()

    start_time = time.time()
    reader_p.join()
    print("Sending {0} numbers to Pipe() took {1} seconds".format(count,(time.time() - start_time)))