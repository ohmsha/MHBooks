# -*- coding: utf-8 -*-
import numpy as np
import time
from multiprocessing import Pool, cpu_count

def pi_monte_carlo_NumPy(num):
    x = np.random.uniform(0, 1, num)
    y = np.random.uniform(0, 1, num)
    judge = x*x + y*y <= 1.0
    return(np.sum(judge))

if __name__ ==  '__main__':
    N = int(10**7)
    workers = cpu_count() # = the number of core
#    num_workers = 1
    print('ワーカ数=', workers)
    N_sub = np.int(N/workers)
    N_list = [N_sub]*workers
    
    with Pool(processes = workers) as p:
        time1 = time.perf_counter()
        sum_total = p.map(pi_monte_carlo_NumPy, N_list)
        pi = sum(sum_total)*4.0/np.float(N)
        time2 = time.perf_counter()
        print(pi)
        print('elapsed time %e' % (time2-time1) )