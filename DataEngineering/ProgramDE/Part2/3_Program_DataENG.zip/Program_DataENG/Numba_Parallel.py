# -*- coding: utf-8 -*-
import numpy as np
import numba
import time

# No parallel
@numba.njit('f8(int32[:])',parallel=False)
def test0(x):
    n = x.shape[0]
    a = np.sin(x)
    b = np.cos(a * a)
    acc = np.float64(0.0)
    for i in range(n - 2):
        for j in range(n - 1):
            acc += b[i] + b[j + 1]
    return acc

# Parallel
@numba.njit('f8(int32[:])',parallel=True)
def test1(x):
    n = x.shape[0]
    a = np.sin(x)
    b = np.cos(a * a)
    acc = np.float64(0.0)
    for i in numba.prange(n - 2):
        for j in numba.prange(n - 1):
            acc += b[i] + b[j + 1]
    return acc

x = np.arange(100000)

time1 = time.perf_counter()
print('test0 =',test0(x))
time2 = time.perf_counter()
print('test1 =',test1(x))
time3 = time.perf_counter()

elapsed_time_1 = time2 - time1
elapsed_time_2 = time3 - time2

print("elapsed time")
print("No Parallel  %e" % elapsed_time_1)
print("Parallel     %e" % elapsed_time_2)
