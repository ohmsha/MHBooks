# -*- coding: utf-8 -*-
# 2.7. Supported NumPy features
#  https://numba.pydata.org/numba-doc/dev/reference/numpysupported.html

import numpy as np
import time
import numba

@numba.njit('void(f8[:,:], f8[:,:], f8[:,:])', nogil=True, parallel=True)
def mul_mat(a, b, c):
    n, m = a.shape
    m, l = b.shape
    for i in numba.prange(n):
        for j in numba.prange(l):
            s = np.float64(0.0)
            for k in numba.prange(m):
                s += a[i,k]*b[k,j]
            c[i,j] = s
    return

def mul_mat_numpy(a, b, c):
    c = np.dot(a, b)
    return

@numba.jit('void(f8[:,:], f8[:,:], f8[:,:])', nogil=True, nopython=True)
def mul_mat_numpy_numba(a, b, c):
    c = np.dot(a, b)
    return

num = 1000
a = np.arange(num*num, dtype=np.float64).reshape(num, num)
b = np.arange(num*num, dtype=np.float64).reshape(num, num)
c = np.zeros(num*num,  dtype=np.float64).reshape(num, num)


time1 = time.perf_counter()
mul_mat(a, b, c)
time2 = time.perf_counter()
mul_mat_numpy(a, b, c)
time3 = time.perf_counter()
mul_mat_numpy_numba(a, b, c)
time4 = time.perf_counter()


elapsed_time_1 = time2 - time1
elapsed_time_2 = time3 - time2
elapsed_time_3 = time4 - time3

print("elapsed time")
print("mul_mat             %e" % elapsed_time_1)
print("mul_mat_numpy       %e" % elapsed_time_2)
print("mul_mat_numpy_numba %e" % elapsed_time_3)
