/*
行列乗算の速度計測：
gcc -v : gcc version 4.8.1
最適化コンパイル gcc -O3
Intel Core i7-4900MQ 2.8GHz
結果:10ms - 17ms

備考：
1)配列要素が大きすぎると実行が不安定になる。これを避けるには
コンパイルオプションとして，-Wl, --stack,10000000 をつけてリンカにスタックメモリ確保を指定するなどの工夫がいる。

2)clock関数は，プロセス占有時間（CPU時間，プロセッサ時間とも言われる）を計測する。時間計測してから，帰ってくるまでの所要時間は
他のプロセスが費やすCPU時間やOSのアイドリングなども含まれる。よって，一般には， プロセス占有時間 < 所要時間　となる。
この単位は処理系により異なるので，定数CLOCKS_PER_SECを見ると良い。この値が，1000ならば単位は[ミリ秒], 1 000 000ならば[マイクロ秒]である。
*/

#include <stdio.h>
#include <time.h>

const int N = 100;
const int M = 1000;
const int L = 100;

int main(void){
	int 	i, j, k, loop, loop_MAX;
	clock_t	c1, c2;
	double	time;
	double	z[N][L], x[N][M], y[M][L];
	
	loop_MAX = 10;
	printf("CLOCKS_PER_SEC = %d \n", CLOCKS_PER_SEC);
	printf("Start\n");
	c1 = clock();
	for (loop=0; loop<loop_MAX; loop++){
		for (i=0; i<N; i++){
			for (j=0; j<L; j++){
				for (k=0; k<M; k++){
					z[i][j] += x[i][k]*y[k][j];
				}
			}
		}
	}
	c2 = clock();
//	time = (double)(c2-c1)/CLOCKS_PER_SEC;
	time = (double)(c2-c1)/ (double)loop_MAX;
	printf("Processing time: %lf [ms]\n", time);
}
