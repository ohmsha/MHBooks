# -*- coding: utf-8 -*-
import numpy as np
import numba
import time
import threading

# GIL
@numba.njit('void(double[:], double[:])', nogil=False)
def func_gil_a(x, y):
    for i in range(len(x)):
        for j in range(len(x)):
            y[i] = np.log( np.exp( np.sqrt(x[i]**3) ) + 1.0/np.float(i+j+1) )
    return

@numba.njit('void(double[:], double[:])', nogil=False)
def func_gil_b(x, y):
    for i in range(len(x)):
        for j in range(len(x)):
            y[i] = np.log( np.exp( np.sqrt(x[i]**3) ) + 1.0/np.float(i+j+1) )
    return

# No GIL
@numba.njit('void(double[:], double[:])', nogil=True)
def func_ngil_a(x, y):
    for i in range(len(x)):
        for j in range(len(x)):
            y[i] = np.log( np.exp( np.sqrt(x[i]**3) ) + 1.0/np.float(i+j+1) )
    return
    
@numba.njit('void(double[:], double[:])', nogil=True)
def func_ngil_b(x, y):
    for i in range(len(x)):
        for j in range(len(x)):
            y[i] = np.log( np.exp( np.sqrt(x[i]**3) ) + 1.0/np.float(i+j+1) )
    return 
    

num = 10000
x1 = np.random.uniform(low=0.1, high=1.0, size=num)
x2 = np.random.uniform(low=0.1, high=1.0, size=num)
y1 = np.zeros(num)
y2 = np.zeros(num)

# No multithread
time1 = time.perf_counter()
func_gil_a(x1, y1)
func_gil_b(x2, y2)
time2 = time.perf_counter()

# Multithread, GIL
thread1 = threading.Thread(target=func_gil_a, args=(x1, y1,))
thread2 = threading.Thread(target=func_gil_b, args=(x2, y2,))
time3 = time.perf_counter()
thread1.start()
thread2.start()
thread1.join()
thread2.join()
time4 = time.perf_counter()

# Multithread, No GIL
thread3 = threading.Thread(target=func_ngil_a, args=(x1, y1,))
thread4 = threading.Thread(target=func_ngil_b, args=(x2, y2,))
time5 = time.perf_counter()
thread3.start()
thread4.start()
thread3.join()
thread4.join()
time6 = time.perf_counter()


elapsed_1 = time2 - time1
elapsed_2 = time4 - time3
elapsed_3 = time6 - time5

print("elapsed time")
print("No multithread     %e" % elapsed_1)
print("Multithread GIL    %e" % elapsed_2)
print("Multithread No GIL %e" % elapsed_3)
