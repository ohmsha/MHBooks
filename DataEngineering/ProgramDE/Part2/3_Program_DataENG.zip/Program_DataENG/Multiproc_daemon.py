# -*- coding: utf-8 -*-
# Daemonの機能を見る
import multiprocessing
import time
 
def worker(num):
    p = multiprocessing.current_process()
    counter = num
    while counter >= 0:
        print('%s(PID %s): counter=%d' % (p.name, p.pid, counter))
        counter -= 1
        time.sleep(0.1)
 
if __name__ == '__main__':
 
# non-daemonic process
    p1 = multiprocessing.Process(target=worker, args=(3,))

# daemonic process
    p2 = multiprocessing.Process(target=worker, args=(10,))
    p2.daemon = True

    p1.start()
    p2.start()

    p1.join()