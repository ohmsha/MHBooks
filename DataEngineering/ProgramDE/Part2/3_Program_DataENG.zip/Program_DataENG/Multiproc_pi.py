# -*- coding: utf-8 -*-
import numpy as np
import time
from multiprocessing import Process, Value, Array
#import ctypes

def pi_monte_carlo(num, id, result):
    count = 0
    for i in range(num.value):
        x = np.random.uniform(0, 1)
        y = np.random.uniform(0, 1)
        judge = x*x + y*y <= 1.0
        count += judge
    result[id.value] = count
    return

if __name__ ==  '__main__':
    N = 1000000
    workers = 2
    N_div = int(N/workers)
    num = Value('i', N_div)
#    num = Value(ctypes.c_int, N_div)
    result = Array('i', [0]*workers)

    id_list = []
    p_list = []
    for i in range(workers):
        id = Value('i', i)
        p  = Process(target = pi_monte_carlo, args=(num, id, result))
        p_list.append(p)

    time1 = time.perf_counter()
    for i in range(workers):
        p_list[i].start()
    for i in range(workers):
        p_list[i].join()
    for i in range(workers):
        p_list[i].close()
    time2 = time.perf_counter()

    print('elapsed time =', time2-time1)
    print('pi=',4.0*np.sum(result)/np.float(N))