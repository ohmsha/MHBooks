from multiprocessing import Process
import os

def func(num):
    print("Number: ", num)
    print("parent process:", os.getppid())
    print("process id:", os.getpid())

if __name__ == '__main__':
    for num in range(10):
        p = Process(target=func, args=(num, ))
        p.start()
        p.join()