# -*- coding: utf-8 -*-
import numpy as np
import time
import numba

def sum1(N):
#    sum = np.int64(0)
    sum = 0.0
    for i in np.arange(N):
        sum += i
    return sum

@numba.jit
def sum1_numba(N):
#    sum = np.int64(0)
    sum = 0.0
    for i in np.arange(N):
        sum += i
    return sum

num = int(10**5)
time1 = time.perf_counter()
print(sum1(num))
time2 = time.perf_counter()
print(sum1_numba(num))
time3 = time.perf_counter()

elapsed_time_1 = time2 - time1
elapsed_time_2 = time3 - time2

print("elapsed time")
print("sum1       %e" % elapsed_time_1)
print("sum1_numba %e" % elapsed_time_2)
