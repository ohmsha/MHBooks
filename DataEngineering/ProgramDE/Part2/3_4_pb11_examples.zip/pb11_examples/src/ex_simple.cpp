﻿// -*- coding: utf-8-with-signature -*- 
// (utf-8, BOM付き)
#include <pybind11/pybind11.h>
#include <iostream>

void say_hello()
{
  std::cout << "Hello, from C++" << std::endl;
}

PYBIND11_MODULE(ex_simple, m) 
{
  m.def("hello",   // Python で扱うときの メソッド名
        say_hello, // 上記に対応付ける関数オブジェクト(関数へのポインタ, C++11のラムダ式等を指定できる)
        u8"ターミナル(標準出力)に'Hello'を表示する"); // 上記メソッド の docstring
}
