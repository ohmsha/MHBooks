﻿// -*- coding: utf-8-with-signature -*- 
// (utf-8, Byte-Order-Mark付き) 

#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
 
double add(double x, double y)
{ return x + y; }

PYBIND11_MODULE(ex_arr1, m) 
{
  m.def("add", pybind11::vectorize(add), 
        u8"二つの numpy array を要素ごとに加算する");
}
