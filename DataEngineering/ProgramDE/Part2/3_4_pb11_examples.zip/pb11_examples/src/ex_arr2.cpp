﻿// -*- coding: utf-8-with-signature -*- 
// (utf-8, BOM付き) 

#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>

pybind11::array_t<double> dot(const pybind11::array_t<double>& x, 
                              const pybind11::array_t<double>& y) 
{
  auto xr = x.unchecked<2>();
  auto yr = y.unchecked<2>();

  if(x.shape(1) != y.shape(0)){
    throw std::runtime_error("Input shapes must match");
  }

  std::vector<ssize_t> shape = {x.shape(0), y.shape(1)};
  auto z = pybind11::array_t<double>(shape);
  auto zr = z.mutable_unchecked<2>();

  memset((void *)zr.mutable_data(0, 0), 0, zr.nbytes()); // z を ゼロ行列にする

  for(ssize_t i = 0; i < z.shape(0); i++){
    for(ssize_t j = 0; j < z.shape(1); j++){
      for(ssize_t k = 0; k < x.shape(1); k++){
        zr(i, j) += xr(i, k) * yr(k, j);
      }
    }
  }

  return z;
}

PYBIND11_MODULE(ex_arr2, m) 
{
  m.def("dot", dot, 
        u8"2次元の numpy array どうしのドット積(行列乗算)を計算する");
}
