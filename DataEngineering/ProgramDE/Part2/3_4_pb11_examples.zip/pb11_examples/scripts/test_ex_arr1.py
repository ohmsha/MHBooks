﻿#!/usr/bin/env python3
import sys
sys.path.append('../build')
import ex_arr1
import numpy as np

def apply_add(a, b):
    print("a = \n", a)
    print("b = \n", b) 
    print("c = a + b = \n", ex_arr1.add(a, b))

apply_add(1, 2)

a = np.array([1, 2, 3])
b = np.array([4, 5, 6])
apply_add(a, b)

a = np.array([[1, 2], [3, 4]])
b = np.array([[5, 6], [7, 8]])
apply_add(a, b)
