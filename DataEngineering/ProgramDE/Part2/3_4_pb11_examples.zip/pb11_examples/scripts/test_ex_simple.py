﻿#!/usr/bin/env python3
import sys
sys.path.append('../build') # モジュールの置き場所に応じて指定する
import ex_simple 

ex_simple.hello() # モジュール内の関数を呼び出す
help(ex_simple.hello) # hello の説明文を表示する


