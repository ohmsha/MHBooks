﻿#!/usr/bin/env python3
import sys
sys.path.append('../build')
import ex_arr2
import numpy as np

A = np.array([[1, 2], [3, 4]])
B = np.array([[5, 6], [7, 8]])

print("A = \n", A)
print("B = \n", B) 
print("C = dot1(A, B) = \n", ex_arr2.dot(A, B))
print("C = dot2(A, B) = \n", np.dot(A, B))


